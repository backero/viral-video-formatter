import { motion } from 'framer-motion';
import {
  Film, Layers, Clock, Hash,
  User, Image, Mic, Volume2, Music, Type,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import type { Phase5Envelope } from '@/types/pipeline';
import { NODE_META } from '@/data/nodeMeta';
import type { LucideIcon } from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  User, Image, Film, Mic, Volume2, Music, Type, Layers,
};

interface SummaryViewProps {
  envelope: Phase5Envelope;
}

export default function SummaryView({ envelope }: SummaryViewProps) {
  const nodes = envelope.documents.ai_node_graph.nodes;
  const scenes = new Set(nodes.map((n) => n.scene_binding).filter(Boolean));
  const sortedScenes = Array.from(scenes).sort((a, b) => a - b);

  return (
    <div className="h-full overflow-y-auto bg-[#0a0c10] p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mx-auto max-w-5xl"
      >
        {/* Header */}
        <div className="mb-8">
          <h2 className="mb-2 text-2xl font-bold text-white">
            {envelope.metadata.title}
          </h2>
          <div className="flex flex-wrap items-center gap-3 text-sm text-white/50">
            <span className="flex items-center gap-1">
              <User className="h-3.5 w-3.5" />
              {envelope.metadata.actor}
            </span>
            <span className="flex items-center gap-1">
              <Film className="h-3.5 w-3.5" />
              {sortedScenes.length} scenes
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {envelope.metadata.length_seconds}s
            </span>
            <span className="flex items-center gap-1">
              <Hash className="h-3.5 w-3.5" />
              {nodes.length} nodes
            </span>
            <Badge className="bg-emerald-500/15 text-emerald-400">
              NPS {envelope.validation_carry.neural_prediction_score}
            </Badge>
          </div>
        </div>

        {/* Scene pipeline cards */}
        <div className="space-y-4">
          {sortedScenes.map((sceneNum, sceneIdx) => {
            const sceneNodes = nodes.filter((n) => n.scene_binding === sceneNum);
            const duration = sceneNodes.find(
              (n) => n.type === 'compositor.scene'
            )?.parameters?.duration_seconds;

            return (
              <motion.div
                key={sceneNum}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: sceneIdx * 0.08, duration: 0.3 }}
                className="rounded-xl border border-white/10 bg-[#12151c] p-5"
              >
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 items-center justify-center rounded-md bg-blue-500/15">
                      <span className="text-xs font-bold text-blue-400">
                        {sceneNum}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-white">
                      Scene {sceneNum}
                    </h3>
                    {duration && (
                      <span className="text-xs text-white/40">
                        {duration}s
                      </span>
                    )}
                  </div>
                </div>

                {/* Pipeline steps */}
                <div className="flex flex-wrap gap-2">
                  {sceneNodes
                    .sort((a, b) => {
                      const order: Record<string, number> = {
                        't2i.keyframe': 0,
                        'i2v.scene': 1,
                        't2v.scene': 1,
                        'tts.voiceover': 2,
                        'audio.lipsync': 3,
                        'overlay.text': 4,
                        'audio.sfx': 5,
                        'transition.cut': 6,
                        'compositor.scene': 7,
                      };
                      return (
                        (order[a.type] ?? 99) - (order[b.type] ?? 99)
                      );
                    })
                    .map((node, i, arr) => (
                      <div key={node.node_id} className="flex items-center gap-2">
                        <SceneStep node={node} />
                        {i < arr.length - 1 && (
                          <div className="h-px w-3 bg-white/10" />
                        )}
                      </div>
                    ))}
                </div>
              </motion.div>
            );
          })}

          {/* Global nodes (music, master, render) */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: sortedScenes.length * 0.08, duration: 0.3 }}
            className="rounded-xl border border-white/10 bg-[#12151c] p-5"
          >
            <div className="mb-4 flex items-center gap-2">
              <div className="flex h-6 w-6 items-center justify-center rounded-md bg-coral-500/15">
                <Layers className="h-3.5 w-3.5 text-[#e07050]" />
              </div>
              <h3 className="text-sm font-semibold text-white">Global Pipeline</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {nodes
                .filter((n) => n.scene_binding === null && n.type !== 'reference.actor')
                .map((node, i, arr) => (
                  <div key={node.node_id} className="flex items-center gap-2">
                    <SceneStep node={node} />
                    {i < arr.length - 1 && (
                      <div className="h-px w-3 bg-white/10" />
                    )}
                  </div>
                ))}
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}

function SceneStep({ node }: { node: { type: string; node_id: string; rendered_prompt: string | null; tool_recommendations: string[] } }) {
  const meta = NODE_META[node.type];
  const IconComp = meta ? (ICON_MAP[meta.icon] ?? Layers) : Layers;
  const color = meta?.color ?? '#6c7a94';

  return (
    <div
      className="rounded-lg border border-white/10 bg-[#0a0c10] px-3 py-2"
      style={{ borderLeft: `3px solid ${color}` }}
    >
      <div className="flex items-center gap-1.5">
        <IconComp className="h-3 w-3" style={{ color }} />
        <span className="text-[11px] font-medium text-white/80">
          {meta?.label ?? node.type}
        </span>
      </div>
      {node.rendered_prompt && (
        <p className="mt-1 max-w-[300px] truncate text-[10px] text-white/30">
          {node.rendered_prompt.slice(0, 60)}
          {node.rendered_prompt.length > 60 ? '...' : ''}
        </p>
      )}
      <p className="text-[9px] text-white/20">{node.tool_recommendations[0]}</p>
    </div>
  );
}
