import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, FileJson } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { validateImport } from '@/utils/validators';
import type { Phase5Envelope } from '@/types/pipeline';

interface ImportModalProps {
  open: boolean;
  onClose: () => void;
  onImport: (envelope: Phase5Envelope) => void;
  addToast: (type: 'success' | 'error', message: string) => void;
}

export default function ImportModal({ open, onClose, onImport, addToast }: ImportModalProps) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const [isDragOver, setIsDragOver] = useState(false);

  const handleImport = useCallback(() => {
    setError('');
    try {
      const json = JSON.parse(text);
      const result = validateImport(json);
      if (result.valid && result.envelope) {
        onImport(result.envelope);
        addToast('success', `Loaded: ${result.envelope.metadata.title} · ${result.envelope.documents.ai_node_graph.nodes.length} nodes`);
        setText('');
        onClose();
      } else {
        setError(result.error ?? 'Unknown validation error');
      }
    } catch {
      setError('Invalid JSON — check your syntax');
    }
  }, [text, onImport, onClose, addToast]);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);
      const file = e.dataTransfer.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        setText(String(ev.target?.result ?? ''));
      };
      reader.readAsText(file);
    },
    []
  );

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.96 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="relative mx-4 w-full max-w-lg rounded-xl border border-white/10 bg-[#12151c] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close */}
            <button
              onClick={onClose}
              className="absolute right-4 top-4 rounded p-1 text-white/40 transition-colors hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>

            <h2 className="mb-1 text-lg font-semibold text-white">Import Phase 5 JSON</h2>
            <p className="mb-4 text-sm text-white/50">
              Paste your Phase 5 envelope JSON below, or drag and drop a file.
            </p>

            {/* Drop zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleDrop}
              className={`mb-3 rounded-lg border-2 border-dashed p-6 text-center transition-colors ${
                isDragOver
                  ? 'border-blue-400 bg-blue-500/10'
                  : 'border-white/10 bg-white/[0.02] hover:border-white/20'
              }`}
            >
              <FileJson className="mx-auto mb-2 h-8 w-8 text-white/30" />
              <p className="text-sm text-white/50">
                Drop Phase 5 JSON file here, or paste below
              </p>
            </div>

            <Textarea
              value={text}
              onChange={(e) => {
                setText(e.target.value);
                setError('');
              }}
              placeholder="Paste Phase 5 JSON here..."
              className="mb-3 h-48 resize-none border-white/10 bg-[#0a0c10] font-mono text-xs text-white/80 placeholder:text-white/20"
            />

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-3 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400"
              >
                {error}
              </motion.div>
            )}

            <div className="flex items-center justify-end gap-2">
              <Button
                variant="ghost"
                onClick={onClose}
                className="text-white/60 hover:bg-white/10 hover:text-white"
              >
                Cancel
              </Button>
              <Button
                onClick={handleImport}
                className="gap-2 bg-blue-600 text-white hover:bg-blue-500"
              >
                <Upload className="h-4 w-4" />
                Import & Load
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
