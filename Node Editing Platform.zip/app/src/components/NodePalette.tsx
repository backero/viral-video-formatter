import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { PALETTE_CATEGORIES, NODE_META } from '@/data/nodeMeta';
import type { LucideIcon } from 'lucide-react';
import {
  User,
  Image,
  Film,
  Video,
  Mic,
  AudioLines,
  Volume2,
  Music,
  Type,
  Scissors,
  Layers,
  LayoutGrid,
  Download,
} from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  User,
  Image,
  Film,
  Video,
  Mic,
  AudioLines,
  Volume2,
  Music,
  Type,
  Scissors,
  Layers,
  LayoutGrid,
  Download,
};

interface NodePaletteProps {
  onDragStart: (nodeType: string) => void;
}

export default function NodePalette({ onDragStart }: NodePaletteProps) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    input: true,
    generate: true,
    audio: true,
    composite: true,
    output: true,
  });

  return (
    <div className="flex h-full w-[200px] flex-col border-r border-white/10 bg-[#12151c]">
      <div className="border-b border-white/10 px-4 py-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-white/40">
          Palette
        </h3>
      </div>

      <div className="flex-1 overflow-y-auto py-2">
        {PALETTE_CATEGORIES.map((cat) => (
          <div key={cat.id}>
            <button
              onClick={() =>
                setExpanded((prev) => ({ ...prev, [cat.id]: !prev[cat.id] }))
              }
              className="flex w-full items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white/60 transition-colors hover:text-white"
            >
              {expanded[cat.id] ? (
                <ChevronDown className="h-3 w-3" />
              ) : (
                <ChevronRight className="h-3 w-3" />
              )}
              {cat.label}
            </button>

            {expanded[cat.id] && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                transition={{ duration: 0.15 }}
                className="px-2 pb-1"
              >
                {cat.types.map((type) => {
                  const meta = NODE_META[type as string];
                  if (!meta) return null;
                  const IconComp = ICON_MAP[meta.icon] ?? Layers;

                  return (
                    <motion.div
                      key={type}
                      draggable
                      onDragStart={() => onDragStart(type as string)}
                      whileHover={{ x: 2, scale: 1.02 }}
                      className="mb-1 flex cursor-grab items-center gap-2.5 rounded-md border border-transparent px-2.5 py-2 transition-all hover:border-white/10 hover:bg-white/[0.04] hover:shadow-md active:cursor-grabbing"
                    >
                      <div
                        className="h-full w-[3px] self-stretch rounded-full"
                        style={{ backgroundColor: meta.color }}
                      />
                      <IconComp
                        className="h-3.5 w-3.5 shrink-0"
                        style={{ color: meta.color }}
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[11px] font-medium text-white/80">
                          {meta.label}
                        </p>
                        <p className="truncate text-[10px] text-white/30">
                          {meta.tools[0]}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
