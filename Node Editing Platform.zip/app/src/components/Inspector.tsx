import { motion, AnimatePresence } from 'framer-motion';
import {
  Copy,
  Trash2,
  Lock,
  User,
  Image,
  Film,
  Video,
  Mic,
  AudioLines,
  Volume2,
  Music,
  Type,
  Scissors,
  Layers,
  LayoutGrid,
  Download,
  Zap,
  CheckCircle2,
  CircleDot,
  AlertCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NODE_META } from '@/data/nodeMeta';
import type { EditorNode, Phase5Envelope } from '@/types/pipeline';
import { getNodeStatus, getSceneTimeRange } from '@/utils/layout';
import type { LucideIcon } from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  User, Image, Film, Video, Mic, AudioLines, Volume2, Music, Type,
  Scissors, Layers, LayoutGrid, Download,
};

interface InspectorProps {
  node: EditorNode | null;
  envelope: Phase5Envelope | null;
  onDelete: (id: string) => void;
  onCopyPrompt: (prompt: string) => void;
}

export default function Inspector({ node, envelope, onDelete, onCopyPrompt }: InspectorProps) {
  return (
    <div className="flex h-full w-[320px] flex-col border-l border-white/10 bg-[#12151c]">
      <div className="border-b border-white/10 px-4 py-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-white/40">
          Inspector
        </h3>
      </div>

      <AnimatePresence mode="wait">
        {!node ? (
          <ProjectSummary key="project" envelope={envelope} />
        ) : (
          <NodeInspector
            key={node.id}
            node={node}
            envelope={envelope}
            onDelete={onDelete}
            onCopyPrompt={onCopyPrompt}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Project Summary (no node selected) ──
function ProjectSummary({ envelope }: { envelope: Phase5Envelope | null }) {
  if (!envelope) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-1 items-center justify-center p-6 text-center"
      >
        <p className="text-sm text-white/30">
          Import a Phase 5 envelope or select a node to inspect its properties.
        </p>
      </motion.div>
    );
  }

  const meta = envelope.metadata;
  const graph = envelope.documents.ai_node_graph;
  const nodeCount = graph.nodes.length;
  const sceneCount = new Set(graph.nodes.map((n) => n.scene_binding).filter(Boolean)).size;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex-1 overflow-y-auto p-4"
    >
      <div className="mb-4 rounded-lg border border-white/10 bg-[#0a0c10] p-4">
        <h4 className="mb-1 text-sm font-semibold text-white">{meta.title}</h4>
        <div className="space-y-1 text-xs text-white/50">
          <p>
            <span className="text-white/30">Actor:</span> {meta.actor}
          </p>
          <p>
            <span className="text-white/30">Platform:</span> {meta.platform}
          </p>
          <p>
            <span className="text-white/30">Duration:</span> {meta.length_seconds}s
          </p>
          <p>
            <span className="text-white/30">Format:</span> {meta.format}
          </p>
          <p>
            <span className="text-white/30">Aspect:</span> {meta.aspect_ratio}
          </p>
          <p>
            <span className="text-white/30">Type:</span> {meta.content_type}
          </p>
        </div>
      </div>

      <div className="mb-4 grid grid-cols-2 gap-2">
        <StatCard label="Nodes" value={nodeCount} icon={<Layers className="h-3.5 w-3.5" />} />
        <StatCard label="Scenes" value={sceneCount} icon={<Film className="h-3.5 w-3.5" />} />
      </div>

      <div className="rounded-lg border border-white/10 bg-[#0a0c10] p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-xs text-white/50">NPS Score</span>
          <Badge className="bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/20">
            {envelope.validation_carry.neural_prediction_score}/100
          </Badge>
        </div>
        <div className="mb-3 h-2 overflow-hidden rounded-full bg-white/10">
          <motion.div
            initial={{ width: 0 }}
            animate={{
              width: `${envelope.validation_carry.neural_prediction_score}%`,
            }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="h-full rounded-full bg-emerald-500"
          />
        </div>
        <div className="flex items-center justify-between text-[10px] text-white/30">
          <span>Verdict: {envelope.validation_carry.verdict}</span>
          <span>Approvals: {envelope.validation_carry.approvals}</span>
        </div>
      </div>

      {/* Dialogue summary */}
      <div className="mt-4 rounded-lg border border-white/10 bg-[#0a0c10] p-4">
        <h5 className="mb-2 text-xs font-semibold text-white/70">Dialogue</h5>
        <div className="space-y-2">
          {envelope.documents.clean_script.dialogue.map((d, i) => (
            <div key={i} className="text-[10px] leading-relaxed text-white/40">
              <span className="text-white/60">Scene {d.scene}:</span> {d.line}
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function StatCard({
  label,
  value,
  icon,
}: {
  label: string;
  value: number;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-white/10 bg-[#0a0c10] p-3">
      <div className="mb-1 flex items-center gap-1.5 text-white/40">{icon}</div>
      <p className="text-lg font-semibold text-white">{value}</p>
      <p className="text-[10px] text-white/40">{label}</p>
    </div>
  );
}

// ── Node Inspector (node selected) ──
function NodeInspector({
  node,
  envelope,
  onDelete,
  onCopyPrompt,
}: {
  node: EditorNode;
  envelope: Phase5Envelope | null;
  onDelete: (id: string) => void;
  onCopyPrompt: (prompt: string) => void;
}) {
  const data = node.data;
  const meta = NODE_META[data.type];
  const IconComp = meta ? (ICON_MAP[meta.icon] ?? Layers) : Layers;
  const status = getNodeStatus(data);
  const isLocked = !!meta?.locked;
  const toolRouting = envelope?.documents.ai_node_graph.tool_routing ?? {};
  const currentTool = toolRouting[data.type] ?? data.tool_recommendations[0] ?? '';
  const sceneTime = data.scene_binding && envelope
    ? getSceneTimeRange(data.scene_binding, envelope.documents.ai_node_graph.nodes)
    : '';

  const statusConfig = {
    ready: { icon: <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />, label: 'Ready' },
    pending: { icon: <CircleDot className="h-3.5 w-3.5 text-amber-400" />, label: 'Pending' },
    broken: { icon: <AlertCircle className="h-3.5 w-3.5 text-red-400" />, label: 'Broken' },
    optional: { icon: <Zap className="h-3.5 w-3.5 text-white/30" />, label: 'Optional' },
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 10 }}
      transition={{ duration: 0.15 }}
      className="flex-1 overflow-y-auto"
    >
      {/* Header */}
      <div className="border-b border-white/10 p-4">
        <div className="mb-2 flex items-center gap-2.5">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${meta?.color ?? '#6c7a94'}22`, borderColor: meta?.color }}
          >
            <IconComp
              className="h-4 w-4"
              style={{ color: meta?.color ?? '#6c7a94' }}
            />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h4 className="truncate text-sm font-semibold text-white">
                {meta?.label ?? data.type}
              </h4>
              {isLocked && (
                <Badge className="bg-amber-500/15 text-[9px] text-amber-400 hover:bg-amber-500/20">
                  <Lock className="mr-1 h-2.5 w-2.5" />
                  {meta?.locked}
                </Badge>
              )}
            </div>
            <p className="text-[10px] text-white/40">{data.node_id}</p>
          </div>
          {statusConfig[status].icon}
        </div>

        {data.scene_binding && (
          <div className="mt-1.5 flex items-center gap-2">
            <Badge className="bg-white/5 text-[10px] text-white/50 hover:bg-white/10">
              Scene {data.scene_binding}
            </Badge>
            {sceneTime && (
              <span className="text-[10px] text-white/30">{sceneTime}</span>
            )}
          </div>
        )}

        {/* Tool */}
        <div className="mt-3 rounded-md border border-white/10 bg-[#0a0c10] p-2.5">
          <label className="mb-1 block text-[10px] uppercase tracking-wider text-white/30">
            Tool
          </label>
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-white/80">{currentTool}</span>
            <Badge className="bg-white/5 text-[9px] text-white/40 hover:bg-white/10">
              {data.tool_recommendations.length} options
            </Badge>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="prompt" className="w-full">
        <TabsList className="w-full rounded-none border-b border-white/10 bg-transparent px-4 py-0">
          {['Prompt', 'Params', 'Connections'].map((tab) => (
            <TabsTrigger
              key={tab}
              value={tab.toLowerCase()}
              className="rounded-none border-b-2 border-transparent py-2.5 text-[11px] data-[state=active]:border-blue-500 data-[state=active]:bg-transparent data-[state=active]:text-white"
            >
              {tab}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="prompt" className="m-0 p-4">
          {data.prompt_template && (
            <div className="mb-3">
              <label className="mb-1 flex items-center gap-1 text-[10px] uppercase tracking-wider text-white/30">
                Template
                {isLocked && <Lock className="h-2.5 w-2.5 text-amber-500" />}
              </label>
              <div className="rounded-md border border-white/10 bg-[#0a0c10] p-2.5">
                <p className="whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-white/60">
                  {data.prompt_template}
                </p>
              </div>
            </div>
          )}

          {data.rendered_prompt && (
            <div>
              <label className="mb-1 flex items-center gap-1 text-[10px] uppercase tracking-wider text-white/30">
                Rendered
                {isLocked && <Lock className="h-2.5 w-2.5 text-amber-500" />}
              </label>
              <div className="rounded-md border border-white/10 bg-[#0a0c10] p-2.5">
                <p className="whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-white/80">
                  {data.rendered_prompt}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="mt-2 h-7 gap-1.5 text-[10px] text-white/50 hover:bg-white/10 hover:text-white"
                onClick={() => onCopyPrompt(data.rendered_prompt ?? '')}
              >
                <Copy className="h-3 w-3" />
                Copy Prompt
              </Button>
            </div>
          )}

          {!data.prompt_template && !data.rendered_prompt && (
            <p className="py-4 text-center text-xs text-white/30">
              No prompt for this node type.
            </p>
          )}
        </TabsContent>

        <TabsContent value="params" className="m-0 p-4">
          {Object.keys(data.parameters).length === 0 ? (
            <p className="py-4 text-center text-xs text-white/30">No parameters.</p>
          ) : (
            <div className="space-y-2">
              {Object.entries(data.parameters).map(([key, val]) => (
                <div
                  key={key}
                  className="rounded-md border border-white/10 bg-[#0a0c10] px-3 py-2"
                >
                  <label className="block text-[10px] uppercase tracking-wider text-white/30">
                    {key}
                  </label>
                  <p className="mt-0.5 break-all font-mono text-[11px] text-white/70">
                    {JSON.stringify(val)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="connections" className="m-0 p-4">
          {Object.keys(data.inputs).length === 0 ? (
            <p className="py-4 text-center text-xs text-white/30">No incoming connections.</p>
          ) : (
            <div className="space-y-2">
              <h5 className="text-[10px] uppercase tracking-wider text-white/30">Incoming</h5>
              {Object.entries(data.inputs).map(([port, input]) => {
                if (Array.isArray(input)) {
                  return input.map((inp, i) => (
                    <ConnectionCard key={`${port}-${i}`} port={port} input={inp} />
                  ));
                }
                return <ConnectionCard key={port} port={port} input={input} />;
              })}
            </div>
          )}

          {Object.keys(data.outputs).length > 0 && (
            <div className="mt-4 space-y-2">
              <h5 className="text-[10px] uppercase tracking-wider text-white/30">Outgoing</h5>
              {Object.entries(data.outputs).map(([port, def]) => (
                <div
                  key={port}
                  className="rounded-md border border-white/10 bg-[#0a0c10] px-3 py-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-medium text-white/70">{port}</span>
                    <Badge className="bg-white/5 text-[9px] text-white/40">{def.type}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Separator className="bg-white/10" />

      {/* Actions */}
      <div className="flex items-center gap-2 p-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onDelete(node.id)}
          className="h-8 gap-1.5 text-xs text-red-400 hover:bg-red-500/15 hover:text-red-300"
        >
          <Trash2 className="h-3.5 w-3.5" />
          Delete
        </Button>
      </div>
    </motion.div>
  );
}

function ConnectionCard({
  port,
  input,
}: {
  port: string;
  input: { from_node: string; port: string };
}) {
  return (
    <div className="rounded-md border border-white/10 bg-[#0a0c10] px-3 py-2">
      <div className="flex items-center gap-1.5 text-[11px]">
        <span className="text-white/50">{input.from_node}</span>
        <span className="text-white/20">&rarr;</span>
        <span className="font-medium text-blue-400">{port}</span>
      </div>
      <p className="mt-0.5 text-[10px] text-white/30">
        output: {input.port}
      </p>
    </div>
  );
}
