import {
  LayoutGrid,
  Webhook,
  RotateCcw,
  Undo2,
  Redo2,
  Upload,
  Download,
  FileJson,
  FileText,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Phase5Envelope, ViewMode } from '@/types/pipeline';
import { countNodeStatuses } from '@/utils/validators';
import { useMemo } from 'react';

interface ToolbarProps {
  envelope: Phase5Envelope | null;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  onImport: () => void;
  onResetLayout: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onExportComfyUI: () => void;
  onExportFreepik: () => void;
  onExportPrompts: () => void;
  onExportJSON: () => void;
}

export default function Toolbar({
  envelope,
  viewMode,
  onViewModeChange,
  onImport,
  onResetLayout,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onExportComfyUI,
  onExportFreepik,
  onExportPrompts,
  onExportJSON,
}: ToolbarProps) {
  const counts = useMemo(() => {
    if (!envelope) return { ready: 0, pending: 0, broken: 0, optional: 0 };
    return countNodeStatuses(envelope);
  }, [envelope]);

  return (
    <div className="flex h-14 shrink-0 items-center justify-between border-b border-white/10 bg-[#12151c] px-4">
      {/* Left: Brand */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-blue-600">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-tight text-white">
              SCALEROCK
            </h1>
            <p className="text-[10px] leading-tight text-white/40">
              Phase 6 &middot; Node Editor
            </p>
          </div>
        </div>

        {envelope && (
          <div className="ml-4 hidden items-center gap-2 border-l border-white/10 pl-4 md:flex">
            <span className="max-w-[200px] truncate text-xs text-white/70 lg:max-w-xs">
              {envelope.metadata.title}
            </span>
            <span className="text-white/20">&middot;</span>
            <span className="text-xs text-white/50">
              {envelope.metadata.actor}
            </span>
            <Badge
              variant="secondary"
              className="bg-emerald-500/15 text-[10px] text-emerald-400 hover:bg-emerald-500/20"
            >
              <CheckCircle2 className="mr-1 h-3 w-3" />
              NPS {envelope.validation_carry.neural_prediction_score}
            </Badge>
          </div>
        )}
      </div>

      {/* Center: View toggle + Actions */}
      <div className="flex items-center gap-1.5">
        <div className="mr-2 flex items-center rounded-lg border border-white/10 bg-[#0a0c10] p-0.5">
          <button
            onClick={() => onViewModeChange('canvas')}
            className={`flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs transition-all ${
              viewMode === 'canvas'
                ? 'bg-white/10 text-white'
                : 'text-white/40 hover:text-white/70'
            }`}
          >
            <Webhook className="h-3.5 w-3.5" />
            Canvas
          </button>
          <button
            onClick={() => onViewModeChange('summary')}
            className={`flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs transition-all ${
              viewMode === 'summary'
                ? 'bg-white/10 text-white'
                : 'text-white/40 hover:text-white/70'
            }`}
          >
            <LayoutGrid className="h-3.5 w-3.5" />
            Summary
          </button>
        </div>

        <div className="h-5 w-px bg-white/10" />

        <Button
          variant="ghost"
          size="sm"
          onClick={onResetLayout}
          className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onUndo}
          disabled={!canUndo}
          className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
        >
          <Undo2 className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onRedo}
          disabled={!canRedo}
          className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white disabled:opacity-30"
        >
          <Redo2 className="h-3.5 w-3.5" />
        </Button>

        <div className="h-5 w-px bg-white/10" />

        <Button
          size="sm"
          onClick={onImport}
          className="h-8 gap-1.5 bg-blue-600 text-xs text-white hover:bg-blue-500"
        >
          <Upload className="h-3.5 w-3.5" />
          Import
        </Button>

        <div className="h-5 w-px bg-white/10" />

        {/* Export dropdown simulation via buttons */}
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={onExportComfyUI}
            className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white"
          >
            <FileJson className="h-3.5 w-3.5" />
            ComfyUI
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onExportFreepik}
            className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Freepik
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onExportPrompts}
            className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white"
          >
            <FileText className="h-3.5 w-3.5" />
            Prompts
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onExportJSON}
            className="h-8 gap-1.5 text-xs text-white/50 hover:bg-white/10 hover:text-white"
          >
            <Download className="h-3.5 w-3.5" />
            JSON
          </Button>
        </div>

        {/* Status counts */}
        {envelope && (
          <div className="ml-2 flex items-center gap-1.5 border-l border-white/10 pl-3">
            <StatusDot color="#22c55e" label={counts.ready} />
            <StatusDot color="#eab308" label={counts.pending} />
          </div>
        )}
      </div>
    </div>
  );
}

function StatusDot({ color, label }: { color: string; label: number }) {
  if (label === 0) return null;
  return (
    <div className="flex items-center gap-1">
      <div
        className="h-2 w-2 rounded-full"
        style={{ backgroundColor: color }}
      />
      <span className="text-[10px] text-white/50">{label}</span>
    </div>
  );
}
