import { memo } from 'react';
import { Handle, Position } from 'reactflow';
import type { LucideIcon } from 'lucide-react';
import {
  User, Image, Film, Video, Mic, AudioLines, Volume2,
  Music, Type, Scissors, Layers, LayoutGrid, Download,
} from 'lucide-react';
import { NODE_META } from '@/data/nodeMeta';
import { getNodeStatus } from '@/utils/layout';
import type { AINode } from '@/types/pipeline';
import './nodeStyles.css';

const ICON_MAP: Record<string, LucideIcon> = {
  User, Image, Film, Video, Mic, AudioLines, Volume2,
  Music, Type, Scissors, Layers, LayoutGrid, Download,
};

interface SceneNodeData {
  data: AINode;
}

function SceneNodeRaw({ data }: SceneNodeData) {
  const meta = NODE_META[data.type];
  const IconComp = meta ? (ICON_MAP[meta.icon] ?? Layers) : Layers;
  const color = meta?.color ?? '#6c7a94';
  const status = getNodeStatus(data);

  const statusClass = {
    ready: 'status-dot--ready',
    pending: 'status-dot--pending',
    broken: 'status-dot--broken',
    optional: 'status-dot--optional',
  }[status];

  // Collect key params to display
  const paramEntries = Object.entries(data.parameters).slice(0, 3);
  const hasPrompt = data.rendered_prompt || data.prompt_template;

  return (
    <div className="scene-node group">
      {/* Input handles */}
      {Object.keys(data.inputs).map((port) => (
        <Handle
          key={`in-${port}`}
          type="target"
          position={Position.Left}
          id={port}
          style={{ top: 'auto', position: 'relative' }}
          className="!absolute !left-[-4px]"
        />
      ))}

      {/* Output handles */}
      {Object.keys(data.outputs).map((port) => (
        <Handle
          key={`out-${port}`}
          type="source"
          position={Position.Right}
          id={port}
          style={{ top: 'auto', position: 'relative' }}
          className="!absolute !right-[-4px]"
        />
      ))}

      <div className="flex">
        {/* Left color bar */}
        <div
          className="scene-node__color-bar"
          style={{ backgroundColor: color }}
        />

        <div className="min-w-0 flex-1">
          {/* Header */}
          <div className="scene-node__header">
            <div className="scene-node__icon">
              <IconComp className="h-3 w-3" style={{ color }} />
            </div>
            <span className="scene-node__label">{meta?.label ?? data.type}</span>
            <div className={`status-dot ${statusClass}`} />
          </div>

          {/* Meta row */}
          <div className="scene-node__meta">
            {data.scene_binding ? (
              <>
                <span>Scene {data.scene_binding}</span>
                <span>&middot;</span>
              </>
            ) : null}
            <span className="truncate">
              {data.tool_recommendations[0] ?? ''}
            </span>
          </div>

          <div className="scene-node__divider" />

          {/* Body */}
          <div className="scene-node__body">
            {hasPrompt && (
              <p className="scene-node__prompt">
                {data.rendered_prompt ?? data.prompt_template}
              </p>
            )}

            {paramEntries.length > 0 && (
              <div className="scene-node__params">
                {paramEntries.map(([k, v]) => (
                  <span key={k} className="scene-node__param-tag">
                    {k}: {String(v).slice(0, 20)}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const SceneNode = memo(SceneNodeRaw);
export default SceneNode;
