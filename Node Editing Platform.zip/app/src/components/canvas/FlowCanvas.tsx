import { useCallback } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  type NodeTypes,
  type EdgeTypes,
  type Connection,
  MarkerType,
} from 'reactflow';
import 'reactflow/dist/style.css';
import SceneNode from './SceneNode';
import type { EditorNode, EditorEdge } from '@/types/pipeline';

const nodeTypes: NodeTypes = {
  sceneNode: SceneNode as unknown as NodeTypes[string],
};

interface FlowCanvasProps {
  nodes: EditorNode[];
  edges: EditorEdge[];
  onNodesChange: (changes: unknown[]) => void;
  onEdgesChange: (changes: unknown[]) => void;
  onConnect: (connection: Connection) => void;
  onNodeClick: (_event: React.MouseEvent, node: { id: string }) => void;
  selectedNodeId: string | null;
}

export default function FlowCanvas({
  nodes,
  edges,
  onNodesChange,
  onEdgesChange,
  onConnect,
  onNodeClick,
}: FlowCanvasProps) {
  const handleConnect = useCallback(
    (connection: Connection) => {
      if (connection.source && connection.target) {
        onConnect(connection);
      }
    },
    [onConnect]
  );

  return (
    <div className="relative h-full w-full">
      <ReactFlow
        nodes={nodes as unknown as Parameters<typeof ReactFlow>[0]['nodes']}
        edges={edges.map((e) => ({
          ...e,
          type: 'default',
          markerEnd: { type: MarkerType.ArrowClosed, color: '#4a9eff' },
          style: {
            stroke: '#4a9eff',
            strokeWidth: 1.5,
            opacity: 0.7,
          },
          animated: true,
        }))}
        nodeTypes={nodeTypes}
        edgeTypes={{} as EdgeTypes}
        onNodesChange={onNodesChange as Parameters<typeof ReactFlow>[0]['onNodesChange']}
        onEdgesChange={onEdgesChange as Parameters<typeof ReactFlow>[0]['onEdgesChange']}
        onConnect={handleConnect}
        onNodeClick={onNodeClick}
        fitView
        fitViewOptions={{ padding: 0.2, duration: 300 }}
        minZoom={0.3}
        maxZoom={1.5}
        defaultViewport={{ x: 0, y: 0, zoom: 0.8 }}
        proOptions={{ hideAttribution: true }}
        style={{ background: '#0a0c10' }}
      >
        {/* Subtle dot grid background */}
        <Background
          gap={20}
          size={1}
          color="rgba(255, 255, 255, 0.03)"
          style={{ backgroundColor: '#0a0c10' }}
        />

        {/* Controls (zoom, fit, etc) */}
        <Controls
          style={{
            background: '#12151c',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 8,
          }}
          className="[&>button]:bg-[#12151c] [&>button]:border-white/10 [&>button]:text-white/60 [&>button:hover]:bg-white/10 [&>button:hover]:text-white"
        />

        {/* Mini map */}
        <MiniMap
          nodeStrokeWidth={2}
          nodeColor={(n: { data?: { type?: string } }) => {
            const colorMap: Record<string, string> = {
              'reference.actor': '#8b7fd4',
              't2i.keyframe': '#4a9eff',
              'i2v.scene': '#4a9eff',
              't2v.scene': '#4a9eff',
              'tts.voiceover': '#2dd4a8',
              'audio.lipsync': '#2dd4a8',
              'audio.sfx': '#f0a030',
              'audio.music': '#e85d9a',
              'overlay.text': '#f0a030',
              'transition.cut': '#6c7a94',
              'compositor.scene': '#6c7a94',
              'compositor.master': '#e07050',
              'render.output': '#e07050',
            };
            return colorMap[n.data?.type ?? ''] ?? '#6c7a94';
          }}
          maskColor="rgba(10, 12, 16, 0.7)"
          className="!bottom-4 !right-4 !h-24 !w-36 !rounded-lg !border !border-white/10 !bg-[#12151c]/80"
        />
      </ReactFlow>

      {/* Scene swimlane labels overlay */}
      <SceneSwimlaneOverlay nodes={nodes} />
    </div>
  );
}

function SceneSwimlaneOverlay({ nodes }: { nodes: EditorNode[] }) {
  // Extract scene groupings from nodes
  const sceneMap = new Map<number, number>();
  nodes.forEach((n) => {
    const scene = n.data.scene_binding;
    if (scene && !sceneMap.has(scene)) {
      sceneMap.set(scene, n.position.y);
    }
  });

  if (sceneMap.size === 0) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden">
      {Array.from(sceneMap.entries()).map(([scene, y]) => (
        <div
          key={scene}
          className="absolute left-0 flex items-center gap-2 pl-2"
          style={{
            top: y - 22,
            opacity: 0.5,
          }}
        >
          <span
            className="h-[1px] w-3"
            style={{ backgroundColor: 'rgba(255,255,255,0.15)' }}
          />
          <span className="whitespace-nowrap text-[10px] font-medium tracking-wide text-white/30">
            Scene {scene}
          </span>
        </div>
      ))}
    </div>
  );
}
