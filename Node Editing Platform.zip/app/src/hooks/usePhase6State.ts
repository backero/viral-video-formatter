import { useState, useCallback, useEffect } from 'react';
import type { Phase5Envelope, AINode, EditorNode, EditorEdge, ViewMode } from '@/types/pipeline';
import { computeAutoLayout } from '@/utils/layout';

const STORAGE_KEY = 'scalerock-phase6-state';

interface HistoryEntry {
  nodes: EditorNode[];
  edges: EditorEdge[];
  envelope: Phase5Envelope | null;
}

function loadFromStorage(): HistoryEntry | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return null;
}

function saveToStorage(state: HistoryEntry) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

export function usePhase6State(demoEnvelope: Phase5Envelope) {
  const [envelope, setEnvelope] = useState<Phase5Envelope | null>(null);
  const [nodes, setNodes] = useState<EditorNode[]>([]);
  const [edges, setEdges] = useState<EditorEdge[]>([]);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('canvas');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // Initialize: try localStorage first, then demo
  useEffect(() => {
    const stored = loadFromStorage();
    if (stored && stored.envelope) {
      setEnvelope(stored.envelope);
      setNodes(stored.nodes);
      setEdges(stored.edges);
    } else {
      loadEnvelope(demoEnvelope);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Push history entry
  const pushHistory = useCallback(
    (newNodes: EditorNode[], newEdges: EditorEdge[], newEnvelope: Phase5Envelope | null) => {
      setHistory((prev) => {
        const trimmed = prev.slice(0, historyIndex + 1);
        const entry: HistoryEntry = {
          nodes: newNodes,
          edges: newEdges,
          envelope: newEnvelope,
        };
        const next = [...trimmed, entry].slice(-50); // max 50
        setHistoryIndex(next.length - 1);
        return next;
      });
    },
    [historyIndex]
  );

  // Load a new envelope
  const loadEnvelope = useCallback(
    (env: Phase5Envelope) => {
      const layout = computeAutoLayout(env.documents.ai_node_graph.nodes);
      setEnvelope(env);
      setNodes(layout.nodes);
      setEdges(layout.edges);
      setSelectedNodeId(null);
      pushHistory(layout.nodes, layout.edges, env);
      saveToStorage({ nodes: layout.nodes, edges: layout.edges, envelope: env });
    },
    [pushHistory]
  );

  // Auto-save to localStorage
  useEffect(() => {
    if (envelope) {
      saveToStorage({ nodes, edges, envelope });
    }
  }, [nodes, edges, envelope]);

  // Undo / Redo
  const undo = useCallback(() => {
    setHistoryIndex((prev) => {
      const next = Math.max(0, prev - 1);
      const entry = history[next];
      if (entry) {
        setNodes(entry.nodes);
        setEdges(entry.edges);
        setEnvelope(entry.envelope);
      }
      return next;
    });
  }, [history]);

  const redo = useCallback(() => {
    setHistoryIndex((prev) => {
      const next = Math.min(history.length - 1, prev + 1);
      const entry = history[next];
      if (entry) {
        setNodes(entry.nodes);
        setEdges(entry.edges);
        setEnvelope(entry.envelope);
      }
      return next;
    });
  }, [history]);

  // Reset layout
  const resetLayout = useCallback(() => {
    if (!envelope) return;
    const layout = computeAutoLayout(envelope.documents.ai_node_graph.nodes);
    setNodes(layout.nodes);
    setEdges(layout.edges);
    pushHistory(layout.nodes, layout.edges, envelope);
  }, [envelope, pushHistory]);

  // Delete a node
  const deleteNode = useCallback(
    (nodeId: string) => {
      setNodes((prev) => prev.filter((n) => n.id !== nodeId));
      setEdges((prev) =>
        prev.filter((e) => e.source !== nodeId && e.target !== nodeId)
      );
      setSelectedNodeId((prev) => (prev === nodeId ? null : prev));
    },
    []
  );

  // Add a new node from palette
  const addNode = useCallback(
    (type: string, position: { x: number; y: number }) => {
      if (!envelope) return;
      const meta =
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (envelope.documents.ai_node_graph as any).nodeTypesMeta?.[type];
      const newAINode: AINode = {
        node_id: `${type}.${Date.now()}`,
        type: type as AINode['type'],
        scene_binding: null,
        tool_recommendations: meta?.tools ?? [],
        parameters: {},
        prompt_template: null,
        rendered_prompt: null,
        inputs: {},
        outputs: meta?.defaultOutputs ?? { output: { type: 'generic' } },
      };

      const editorNode: EditorNode = {
        id: newAINode.node_id,
        type: 'sceneNode',
        position,
        data: newAINode,
      };

      setNodes((prev) => [...prev, editorNode]);
    },
    [envelope]
  );

  // On nodes/edges change from React Flow
  const onNodesChange = useCallback(
    (changes: unknown[]) => {
      // Handle position changes from React Flow
      setNodes((prev) => {
        let next = [...prev];
        for (const change of changes as Array<{
          id: string;
          type: string;
          dragging?: boolean;
          position?: { x: number; y: number };
        }>) {
          if (change.type === 'position' && change.position) {
            next = next.map((n) =>
              n.id === change.id ? { ...n, position: change.position! } : n
            );
          } else if (change.type === 'remove') {
            next = next.filter((n) => n.id !== change.id);
          }
        }
        return next;
      });
    },
    []
  );

  const onEdgesChange = useCallback((changes: unknown[]) => {
    setEdges((prev) => {
      let next = [...prev];
      for (const change of changes as Array<{ type: string; id: string }>) {
        if (change.type === 'remove') {
          next = next.filter((e) => e.id !== change.id);
        }
      }
      return next;
    });
  }, []);

  const onConnect = useCallback((connection: {
    source: string;
    target: string;
    sourceHandle?: string | null;
    targetHandle?: string | null;
  }) => {
    const id = `${connection.source}->${connection.target}`;
    setEdges((prev) => {
      if (prev.find((e) => e.id === id)) return prev;
      return [
        ...prev,
        {
          id,
          source: connection.source,
          target: connection.target,
          sourceHandle: connection.sourceHandle ?? undefined,
          targetHandle: connection.targetHandle ?? undefined,
          animated: true,
        },
      ];
    });
  }, []);

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) ?? null;

  return {
    envelope,
    nodes,
    edges,
    selectedNodeId,
    selectedNode,
    viewMode,
    canUndo: historyIndex > 0,
    canRedo: historyIndex < history.length - 1,
    setViewMode,
    setSelectedNodeId,
    loadEnvelope,
    undo,
    redo,
    resetLayout,
    deleteNode,
    addNode,
    onNodesChange,
    onEdgesChange,
    onConnect,
  };
}
