import { useCallback } from 'react';
import type { Phase5Envelope, AINode } from '@/types/pipeline';
import {
  exportComfyUI,
  exportFreepik,
  exportPromptSheet,
  exportRoundTrip,
  downloadFile,
} from '@/utils/exporters';
import type { EditorNode } from '@/types/pipeline';

export function useExports() {
  const exportComfyUIWorkflow = useCallback(
    (envelope: Phase5Envelope) => {
      const data = exportComfyUI(envelope);
      downloadFile(
        JSON.stringify(data, null, 2),
        `comfyui-workflow-${slugify(envelope.metadata.title)}.json`,
        'application/json'
      );
    },
    []
  );

  const exportFreepikGraph = useCallback(
    (envelope: Phase5Envelope) => {
      const data = exportFreepik(envelope);
      downloadFile(
        JSON.stringify(data, null, 2),
        `freepik-graph-${slugify(envelope.metadata.title)}.json`,
        'application/json'
      );
    },
    []
  );

  const exportPrompts = useCallback(
    (envelope: Phase5Envelope) => {
      const md = exportPromptSheet(envelope);
      downloadFile(
        md,
        `prompt-sheet-${slugify(envelope.metadata.title)}.md`,
        'text/markdown'
      );
    },
    []
  );

  const exportRoundTripJSON = useCallback(
    (envelope: Phase5Envelope, editorNodes: EditorNode[]) => {
      const updatedNodes: AINode[] = editorNodes.map((n) => n.data);
      const data = exportRoundTrip(envelope, updatedNodes);
      downloadFile(
        JSON.stringify(data, null, 2),
        `phase5-updated-${slugify(envelope.metadata.title)}.json`,
        'application/json'
      );
    },
    []
  );

  return {
    exportComfyUIWorkflow,
    exportFreepikGraph,
    exportPrompts,
    exportRoundTripJSON,
  };
}

function slugify(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}
