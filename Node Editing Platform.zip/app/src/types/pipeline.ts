// ═══════════════════════════════════════════════════════════════════════════
// Scalerock Phase 6 — Type Definitions
// ═══════════════════════════════════════════════════════════════════════════

export type NodeType =
  | 'reference.actor'
  | 't2i.keyframe'
  | 'i2v.scene'
  | 't2v.scene'
  | 'tts.voiceover'
  | 'audio.lipsync'
  | 'audio.sfx'
  | 'audio.music'
  | 'overlay.text'
  | 'transition.cut'
  | 'compositor.scene'
  | 'compositor.master'
  | 'render.output';

export interface InputRef {
  from_node: string;
  port: string;
}

export interface OutputDef {
  type: string;
  schema?: string;
}

export interface AINode {
  node_id: string;
  type: NodeType;
  scene_binding: number | null;
  tool_recommendations: string[];
  parameters: Record<string, unknown>;
  prompt_template: string | null;
  rendered_prompt: string | null;
  inputs: Record<string, InputRef | InputRef[]>;
  outputs: Record<string, OutputDef>;
}

export interface Phase5Metadata {
  title: string;
  actor: string;
  company?: string;
  platform: string;
  length_seconds: number;
  aspect_ratio: string;
  format: string;
  content_type: string;
}

export interface ValidationCarry {
  verdict: 'SHIP' | 'REVISE' | 'REJECT';
  neural_prediction_score: number;
  approvals?: string;
}

export interface CleanScript {
  dialogue: Array<{ scene: number; speaker: string; line: string }>;
}

export interface AINodeGraph {
  tool_routing: Record<string, string>;
  nodes: AINode[];
}

export interface Phase5Envelope {
  phase: number;
  metadata: Phase5Metadata;
  validation_carry: ValidationCarry;
  documents: {
    ai_node_graph: AINodeGraph;
    clean_script: CleanScript;
  };
}

// ── Node type metadata ──
export interface NodeMetaEntry {
  color: string;
  label: string;
  tools: string[];
  locked?: string;
  icon: string;
}

export type NodeMetaMap = Record<string, NodeMetaEntry>;

// ── Editor state ──
export interface EditorNode {
  id: string;
  type: string; // react flow node type (our custom key)
  position: { x: number; y: number };
  data: AINode;
}

export interface EditorEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: string;
  animated?: boolean;
}

export interface GraphState {
  nodes: EditorNode[];
  edges: EditorEdge[];
  envelope: Phase5Envelope | null;
}

export type ViewMode = 'canvas' | 'summary';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  id: string;
  type: ToastType;
  message: string;
}
