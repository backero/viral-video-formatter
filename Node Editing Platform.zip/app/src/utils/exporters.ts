import type { Phase5Envelope, AINode } from '@/types/pipeline';

// ── 1. ComfyUI Export ──
export function exportComfyUI(envelope: Phase5Envelope): object {
  const nodes = envelope.documents.ai_node_graph.nodes;
  const comfyNodes: Record<string, unknown>[] = [];
  const comfyLinks: [number, number, number, number, number][] = [];

  const nodeIdMap: Record<string, number> = {};

  nodes.forEach((node, index) => {
    const comfyId = index + 1;
    nodeIdMap[node.node_id] = comfyId;

    const comfyNode: Record<string, unknown> = {
      id: comfyId,
      type: mapToComfyUIType(node.type),
      pos: [0, 0],
      size: { '0': 200, '1': 200 },
      flags: {},
      order: comfyId,
      mode: 0,
      inputs: [],
      outputs: [],
      widgets_values: [],
    };

    // Add prompt as widget value
    if (node.rendered_prompt) {
      (comfyNode.widgets_values as unknown[]).push(node.rendered_prompt);
    }

    // Add parameters as widget values
    Object.entries(node.parameters).forEach(([key, val]) => {
      (comfyNode.widgets_values as unknown[]).push(`${key}: ${val}`);
    });

    // Add outputs
    Object.entries(node.outputs).forEach(([port, def], portIdx) => {
      (comfyNode.outputs as unknown[]).push({
        name: port,
        type: def.type,
        links: [],
        slot_index: portIdx,
      });
    });

    comfyNodes.push(comfyNode);
  });

  // Create links from inputs
  let linkId = 1;
  nodes.forEach((node) => {
    const targetId = nodeIdMap[node.node_id];
    Object.entries(node.inputs).forEach(([_port, input]) => {
      if (Array.isArray(input)) {
        input.forEach((inp) => {
          const sourceId = nodeIdMap[inp.from_node];
          if (sourceId && targetId) {
            const sourceSlot = 0;
            const targetSlot = 0;
            comfyLinks.push([linkId, sourceId, sourceSlot, targetId, targetSlot]);
            linkId++;
          }
        });
      } else if (input && input.from_node) {
        const sourceId = nodeIdMap[input.from_node];
        if (sourceId && targetId) {
          const sourceSlot = 0;
          const targetSlot = 0;
          comfyLinks.push([linkId, sourceId, sourceSlot, targetId, targetSlot]);
          linkId++;
        }
      }
    });
  });

  return {
    last_node_id: nodes.length,
    last_link_id: linkId - 1,
    nodes: comfyNodes,
    links: comfyLinks,
    groups: [],
    config: {},
    extra: {},
    version: 0.4,
  };
}

function mapToComfyUIType(type: string): string {
  const map: Record<string, string> = {
    'reference.actor': 'LoadImage',
    't2i.keyframe': 'KSampler',
    'i2v.scene': 'VHS_LoadVideo',
    't2v.scene': 'AnimateDiffLoader',
    'tts.voiceover': 'ElevenLabsTTS',
    'audio.lipsync': 'Wav2Lip',
    'audio.sfx': 'LoadAudio',
    'audio.music': 'LoadAudio',
    'overlay.text': 'TextOverlay',
    'transition.cut': 'VideoCombine',
    'compositor.scene': 'VideoCombine',
    'compositor.master': 'VideoCombine',
    'render.output': 'SaveVideo',
  };
  return map[type] ?? 'Node';
}

// ── 2. Freepik Export ──
export function exportFreepik(envelope: Phase5Envelope): object {
  const graph = envelope.documents.ai_node_graph;
  const nodes = graph.nodes.map((n) => ({
    id: n.node_id,
    type: mapToFreepikTier(n.type),
    tool: graph.tool_routing[n.type] ?? n.tool_recommendations[0] ?? '',
    prompt: n.rendered_prompt ?? n.prompt_template ?? '',
    prompt_template: n.prompt_template,
    parameters: n.parameters,
    scene_binding: n.scene_binding,
    engine: graph.tool_routing[n.type] ?? '',
  }));

  const edges: Record<string, unknown>[] = [];
  graph.nodes.forEach((node) => {
    Object.entries(node.inputs).forEach(([port, input]) => {
      if (Array.isArray(input)) {
        input.forEach((inp) => {
          edges.push({
            from_node_id: inp.from_node,
            from_port: inp.port,
            to_node_id: node.node_id,
            to_port: port,
          });
        });
      } else if (input && input.from_node) {
        edges.push({
          from_node_id: input.from_node,
          from_port: input.port,
          to_node_id: node.node_id,
          to_port: port,
        });
      }
    });
  });

  return {
    version: '1.0',
    title: envelope.metadata.title,
    aspect_ratio: envelope.metadata.aspect_ratio,
    nodes,
    edges,
  };
}

function mapToFreepikTier(type: string): string {
  if (type === 'reference.actor' || type === 'audio.music') return 'asset-input';
  if (
    type === 't2i.keyframe' ||
    type === 'i2v.scene' ||
    type === 't2v.scene' ||
    type === 'tts.voiceover' ||
    type === 'audio.sfx' ||
    type === 'overlay.text'
  )
    return 'generator';
  return 'compositor';
}

// ── 3. Prompt Sheet (markdown) ──
export function exportPromptSheet(envelope: Phase5Envelope): string {
  const graph = envelope.documents.ai_node_graph;
  const nodes = graph.nodes;

  // Group by tool
  const byTool: Record<string, { node: AINode; scene: number | null }[]> = {};

  nodes.forEach((node) => {
    const tool = graph.tool_routing[node.type] ?? node.tool_recommendations[0] ?? 'unknown';
    if (!byTool[tool]) byTool[tool] = [];
    byTool[tool].push({ node, scene: node.scene_binding });
  });

  // Sort within each tool by scene then type
  Object.values(byTool).forEach((arr) => {
    arr.sort((a, b) => {
      if (a.scene !== b.scene) return (a.scene ?? 999) - (b.scene ?? 999);
      return a.node.node_id.localeCompare(b.node.node_id);
    });
  });

  const toolOrder = ['midjourney', 'midjourney-cref', 'kling-2.0-master', 'runway-gen4', 'elevenlabs', 'elevenlabs-sfx', 'epidemic-load', 'compositor-capcut'];
  const sortedTools = Object.keys(byTool).sort(
    (a, b) => toolOrder.indexOf(a) - toolOrder.indexOf(b)
  );

  let md = `# Prompt Sheet — ${envelope.metadata.title}\n\n`;
  md += `**Actor:** ${envelope.metadata.actor} | **Platform:** ${envelope.metadata.platform} | **Duration:** ${envelope.metadata.length_seconds}s | **Format:** ${envelope.metadata.format}\n\n`;
  md += '---\n\n';

  sortedTools.forEach((tool) => {
    md += `## Tool: ${tool}\n\n`;
    byTool[tool].forEach(({ node, scene }) => {
      const sceneLabel = scene ? `Scene ${scene}` : 'Global';
      const locked = node.type === 'tts.voiceover' || node.type === 'overlay.text' ? ' *(LOCKED)*' : '';
      md += `**${sceneLabel} · ${node.type}** \`${node.node_id}\`${locked}\n\n`;
      if (node.rendered_prompt) {
        md += `> ${node.rendered_prompt}\n\n`;
      } else if (node.prompt_template) {
        md += `> ${node.prompt_template}\n\n`;
      }
      if (Object.keys(node.parameters).length > 0) {
        md += '| Parameter | Value |\n|---|---|\n';
        Object.entries(node.parameters).forEach(([k, v]) => {
          md += `| ${k} | ${JSON.stringify(v)} |\n`;
        });
        md += '\n';
      }
    });
  });

  md += '---\n\n*Generated by Scalerock Phase 6 Node Editor*\n';
  return md;
}

// ── 4. Round-trip Phase 5 Export ──
export function exportRoundTrip(
  envelope: Phase5Envelope,
  updatedNodes: AINode[]
): Phase5Envelope {
  return {
    ...envelope,
    documents: {
      ...envelope.documents,
      ai_node_graph: {
        ...envelope.documents.ai_node_graph,
        nodes: updatedNodes,
      },
    },
  };
}

/** Download a file */
export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
