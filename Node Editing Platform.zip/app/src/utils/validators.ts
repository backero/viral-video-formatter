import type { Phase5Envelope, EditorEdge } from '@/types/pipeline';

export interface ImportResult {
  valid: boolean;
  error?: string;
  envelope?: Phase5Envelope;
}

export function validateImport(json: unknown): ImportResult {
  if (!json || typeof json !== 'object') {
    return { valid: false, error: 'Invalid JSON: must be an object' };
  }

  const envelope = json as Record<string, unknown>;

  // Check phase
  if (envelope.phase !== 5) {
    return { valid: false, error: `Expected phase 5, got phase ${envelope.phase}` };
  }

  // Check documents
  if (!envelope.documents || typeof envelope.documents !== 'object') {
    return { valid: false, error: 'Missing documents field' };
  }

  const docs = envelope.documents as Record<string, unknown>;
  if (!docs.ai_node_graph || typeof docs.ai_node_graph !== 'object') {
    return { valid: false, error: 'Missing ai_node_graph in documents' };
  }

  const graph = docs.ai_node_graph as Record<string, unknown>;
  if (!Array.isArray(graph.nodes) || graph.nodes.length === 0) {
    return { valid: false, error: 'ai_node_graph.nodes must be a non-empty array' };
  }

  // Check validation carry
  if (envelope.validation_carry && typeof envelope.validation_carry === 'object') {
    const vc = envelope.validation_carry as Record<string, unknown>;
    if (vc.verdict !== 'SHIP') {
      return {
        valid: false,
        error: `validation_carry.verdict is "${vc.verdict}" — must be "SHIP" to edit. Route back to Phase 4/3.`,
      };
    }
  }

  return { valid: true, envelope: json as Phase5Envelope };
}

/** Detect cycles in the graph using DFS */
export function detectCycles(
  edges: EditorEdge[]
): { hasCycle: boolean; cycleNodes: string[] } {
  const adj: Record<string, string[]> = {};
  const allNodes = new Set<string>();

  edges.forEach((e) => {
    if (!adj[e.source]) adj[e.source] = [];
    adj[e.source].push(e.target);
    allNodes.add(e.source);
    allNodes.add(e.target);
  });

  const visiting = new Set<string>();
  const visited = new Set<string>();
  const cycleNodes: string[] = [];

  function dfs(node: string, path: string[]): boolean {
    if (visiting.has(node)) {
      const cycleStart = path.indexOf(node);
      cycleNodes.push(...path.slice(cycleStart));
      return true;
    }
    if (visited.has(node)) return false;

    visiting.add(node);
    path.push(node);

    for (const neighbor of adj[node] ?? []) {
      if (dfs(neighbor, path)) return true;
    }

    path.pop();
    visiting.delete(node);
    visited.add(node);
    return false;
  }

  for (const node of allNodes) {
    if (!visited.has(node)) {
      if (dfs(node, [])) return { hasCycle: true, cycleNodes };
    }
  }

  return { hasCycle: false, cycleNodes: [] };
}

/** Count status indicators */
export function countNodeStatuses(
  envelope: Phase5Envelope
): { ready: number; pending: number; broken: number; optional: number } {
  let ready = 0;
  let pending = 0;
  let broken = 0;
  let optional = 0;

  envelope.documents.ai_node_graph.nodes.forEach((node) => {
    const hasInputs = Object.keys(node.inputs).length > 0;
    const tool = node.tool_recommendations?.[0];

    if (!tool && !['reference.actor', 't2i.keyframe', 'tts.voiceover', 'overlay.text', 'audio.sfx', 'audio.music'].includes(node.type)) {
      pending++;
    } else if (!hasInputs && ['i2v.scene', 't2v.scene', 'compositor.scene', 'compositor.master', 'render.output'].includes(node.type)) {
      broken++;
    } else if (node.type === 'audio.lipsync' || node.type === 'transition.cut') {
      optional++;
    } else {
      ready++;
    }
  });

  return { ready, pending, broken, optional };
}
