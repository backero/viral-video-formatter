import type { AINode, EditorNode, EditorEdge } from '@/types/pipeline';
import { LANE_CONFIG, NODE_META, DEFAULT_TOOL_ROUTING } from '@/data/nodeMeta';

/**
 * Auto-layout algorithm: scene swimlanes
 * 1. ref.actor at top (full width)
 * 2. Per scene: horizontal strip with nodes in pipeline order
 * 3. Master row: music → master → render at bottom
 */
export function computeAutoLayout(
  nodes: AINode[]
): { nodes: EditorNode[]; edges: EditorEdge[] } {
  const editorNodes: EditorNode[] = [];
  const editorEdges: EditorEdge[] = [];

  // Group nodes by scene + category
  const refNode = nodes.find((n) => n.type === 'reference.actor');
  const musicNode = nodes.find((n) => n.type === 'audio.music');
  const masterNode = nodes.find((n) => n.type === 'compositor.master');
  const renderNode = nodes.find((n) => n.type === 'render.output');
  const sceneNodes = nodes.filter(
    (n) => n.scene_binding !== null && !['reference.actor', 'audio.music', 'compositor.master', 'render.output'].includes(n.type)
  );
  const masterRowNodes = [musicNode, masterNode, renderNode].filter(Boolean) as AINode[];

  // Determine max scene number
  const maxScene = Math.max(
    ...sceneNodes.map((n) => n.scene_binding ?? 0),
    0
  );

  // Position ref.actor at top
  if (refNode) {
    editorNodes.push({
      id: refNode.node_id,
      type: 'sceneNode',
      position: { x: 40, y: LANE_CONFIG.refActorY },
      data: refNode,
    });
  }

  // For each scene, position nodes in pipeline order
  for (let sceneNum = 1; sceneNum <= maxScene; sceneNum++) {
    const laneY = LANE_CONFIG.sceneStartY + (sceneNum - 1) * LANE_CONFIG.laneHeight;
    const sceneSpecificNodes = sceneNodes.filter(
      (n) => n.scene_binding === sceneNum
    );

    // Order within scene: keyframe → i2v/t2v → tts → overlays → sfx → comp
    const typeOrder: Record<string, number> = {
      't2i.keyframe': 0,
      'i2v.scene': 1,
      't2v.scene': 1,
      'tts.voiceover': 2,
      'audio.lipsync': 3,
      'overlay.text': 4,
      'audio.sfx': 5,
      'transition.cut': 6,
      'compositor.scene': 7,
    };

    const sorted = sceneSpecificNodes.sort(
      (a, b) =>
        (typeOrder[a.type] ?? 99) - (typeOrder[b.type] ?? 99)
    );

    sorted.forEach((node, index) => {
      editorNodes.push({
        id: node.node_id,
        type: 'sceneNode',
        position: {
          x: LANE_CONFIG.nodeStartX + index * LANE_CONFIG.nodeSpacingX,
          y: laneY,
        },
        data: node,
      });
    });
  }

  // Master row at the bottom
  if (masterRowNodes.length > 0) {
    const masterY =
      LANE_CONFIG.sceneStartY + maxScene * LANE_CONFIG.laneHeight + 20;
    masterRowNodes.forEach((node, index) => {
      editorNodes.push({
        id: node.node_id,
        type: 'sceneNode',
        position: {
          x: LANE_CONFIG.nodeStartX + index * (LANE_CONFIG.nodeSpacingX + 60),
          y: masterY,
        },
        data: node,
      });
    });
  }

  // Build edges from node inputs
  nodes.forEach((node) => {
    Object.entries(node.inputs).forEach(([port, input]) => {
      if (Array.isArray(input)) {
        input.forEach((inp) => {
          const edgeId = `${inp.from_node}.${inp.port}->${node.node_id}.${port}`;
          if (!editorEdges.find((e) => e.id === edgeId)) {
            editorEdges.push({
              id: edgeId,
              source: inp.from_node,
              target: node.node_id,
              sourceHandle: inp.port,
              targetHandle: port,
              animated: true,
            });
          }
        });
      } else if (input && input.from_node) {
        const edgeId = `${input.from_node}.${input.port}->${node.node_id}.${port}`;
        if (!editorEdges.find((e) => e.id === edgeId)) {
          editorEdges.push({
            id: edgeId,
            source: input.from_node,
            target: node.node_id,
            sourceHandle: input.port,
            targetHandle: port,
            animated: true,
          });
        }
      }
    });
  });

  return { nodes: editorNodes, edges: editorEdges };
}

/** Get node status: fully bound, pending param, broken edge, optional */
export function getNodeStatus(node: AINode): 'ready' | 'pending' | 'broken' | 'optional' {
  const meta = NODE_META[node.type];

  // Optional nodes check
  if (meta?.locked) {
    // Locked nodes with no tool selected are pending
    const tool = node.tool_recommendations[0] ?? DEFAULT_TOOL_ROUTING[node.type];
    if (!tool) return 'pending';
  }

  // Check if any required inputs are missing
  const inputEntries = Object.entries(node.inputs);
  if (inputEntries.length === 0 && node.type !== 't2i.keyframe' && node.type !== 'tts.voiceover' && node.type !== 'overlay.text' && node.type !== 'audio.sfx') {
    return 'ready';
  }

  // Check for broken edges (inputs that reference non-existent upstream)
  // This is a simplified check
  const hasInputs = Object.keys(node.inputs).length > 0;
  if (hasInputs) {
    return 'ready';
  }

  // Keyframe, TTS, overlay, sfx with no inputs are ready (they're generators)
  if (
    node.type === 't2i.keyframe' ||
    node.type === 'tts.voiceover' ||
    node.type === 'overlay.text' ||
    node.type === 'audio.sfx' ||
    node.type === 'audio.music' ||
    node.type === 'reference.actor'
  ) {
    return 'ready';
  }

  return 'optional';
}

/** Get scene time range string */
export function getSceneTimeRange(
  sceneNum: number,
  nodes: AINode[]
): string {
  const comp = nodes.find(
    (n) => n.type === 'compositor.scene' && n.scene_binding === sceneNum
  );
  const dur = comp?.parameters?.duration_seconds;
  if (!dur) return '';

  // Calculate start time by summing durations of previous scenes
  let startTime = 0;
  for (let i = 1; i < sceneNum; i++) {
    const prev = nodes.find(
      (n) => n.type === 'compositor.scene' && n.scene_binding === i
    );
    startTime += (prev?.parameters?.duration_seconds as number) ?? 0;
  }

  return `${startTime}s-${(startTime + (dur as number)).toFixed(0)}s`;
}
