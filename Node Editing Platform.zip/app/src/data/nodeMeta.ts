import type { NodeMetaMap } from '@/types/pipeline';

export const NODE_META: NodeMetaMap = {
  'reference.actor': {
    color: '#8b7fd4',
    label: 'Actor Ref',
    tools: ['midjourney-cref', 'flux-redux', 'kling-lookbook'],
    icon: 'User',
  },
  't2i.keyframe': {
    color: '#4a9eff',
    label: 'Keyframe',
    tools: ['midjourney', 'flux-1-dev', 'ideogram', 'freepik-flux'],
    icon: 'Image',
  },
  'i2v.scene': {
    color: '#4a9eff',
    label: 'Image→Video',
    tools: ['kling-2.0-master', 'runway-gen4', 'pika-2.2', 'luma-ray2', 'seedance'],
    icon: 'Film',
  },
  't2v.scene': {
    color: '#4a9eff',
    label: 'Text→Video',
    tools: ['kling-2.0-master', 'runway-gen4', 'pika-2.2', 'seedance'],
    icon: 'Video',
  },
  'tts.voiceover': {
    color: '#2dd4a8',
    label: 'Voiceover',
    tools: ['elevenlabs', 'playht', 'openai-tts'],
    locked: 'dialogue',
    icon: 'Mic',
  },
  'audio.lipsync': {
    color: '#2dd4a8',
    label: 'Lip Sync',
    tools: ['sync.so', 'wav2lip'],
    icon: 'AudioLines',
  },
  'audio.sfx': {
    color: '#f0a030',
    label: 'SFX',
    tools: ['elevenlabs-sfx', 'freesound-load'],
    icon: 'Volume2',
  },
  'audio.music': {
    color: '#e85d9a',
    label: 'Music',
    tools: ['epidemic-load', 'suno', 'udio'],
    icon: 'Music',
  },
  'overlay.text': {
    color: '#f0a030',
    label: 'Text Overlay',
    tools: ['compositor-capcut', 'compositor-premiere'],
    locked: 'text',
    icon: 'Type',
  },
  'transition.cut': {
    color: '#6c7a94',
    label: 'Cut',
    tools: ['compositor-capcut'],
    icon: 'Scissors',
  },
  'compositor.scene': {
    color: '#6c7a94',
    label: 'Scene Comp',
    tools: ['compositor-capcut'],
    icon: 'Layers',
  },
  'compositor.master': {
    color: '#e07050',
    label: 'Master Comp',
    tools: ['compositor-capcut'],
    icon: 'LayoutGrid',
  },
  'render.output': {
    color: '#e07050',
    label: 'Render',
    tools: ['compositor-capcut'],
    icon: 'Download',
  },
};

// ── Palette categories ──
export const PALETTE_CATEGORIES = [
  {
    id: 'input',
    label: 'Input',
    types: ['reference.actor'] as const,
  },
  {
    id: 'generate',
    label: 'Generate',
    types: ['t2i.keyframe', 'i2v.scene', 't2v.scene'] as const,
  },
  {
    id: 'audio',
    label: 'Audio',
    types: ['tts.voiceover', 'audio.lipsync', 'audio.sfx', 'audio.music'] as const,
  },
  {
    id: 'composite',
    label: 'Composite',
    types: ['overlay.text', 'transition.cut', 'compositor.scene', 'compositor.master'] as const,
  },
  {
    id: 'output',
    label: 'Output',
    types: ['render.output'] as const,
  },
];

// ── Default tool routing ──
export const DEFAULT_TOOL_ROUTING: Record<string, string> = {
  'reference.actor': 'midjourney-cref',
  't2i.keyframe': 'midjourney',
  'i2v.scene': 'kling-2.0-master',
  't2v.scene': 'kling-2.0-master',
  'tts.voiceover': 'elevenlabs',
  'audio.lipsync': 'sync.so',
  'audio.sfx': 'elevenlabs-sfx',
  'audio.music': 'epidemic-load',
  'overlay.text': 'compositor-capcut',
  'transition.cut': 'compositor-capcut',
  'compositor.scene': 'compositor-capcut',
  'compositor.master': 'compositor-capcut',
  'render.output': 'compositor-capcut',
};

// ── Swimlane layout config ──
export const LANE_CONFIG = {
  refActorY: 40,
  sceneStartY: 200,
  laneHeight: 220,
  nodeStartX: 40,
  nodeSpacingX: 220,
  masterRowY: -1, // computed dynamically
};
