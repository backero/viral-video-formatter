import { useState, useCallback } from 'react';
import ReactFlow, { ReactFlowProvider } from 'reactflow';
import 'reactflow/dist/style.css';
import { usePhase6State } from '@/hooks/usePhase6State';
import { useExports } from '@/hooks/useExports';
import { useToast } from '@/hooks/useToast';
import { DEMO_ENVELOPE } from '@/data/demoEnvelope';
import Toolbar from '@/components/Toolbar';
import NodePalette from '@/components/NodePalette';
import Inspector from '@/components/Inspector';
import FlowCanvas from '@/components/canvas/FlowCanvas';
import SummaryView from '@/components/SummaryView';
import ImportModal from '@/components/ImportModal';
import ToastContainer from '@/components/Toast';

export default function App() {
  const {
    envelope,
    nodes,
    edges,
    selectedNodeId,
    selectedNode,
    viewMode,
    canUndo,
    canRedo,
    setViewMode,
    setSelectedNodeId,
    loadEnvelope,
    undo,
    redo,
    resetLayout,
    deleteNode,
    onNodesChange,
    onEdgesChange,
    onConnect,
  } = usePhase6State(DEMO_ENVELOPE);

  const { toasts, addToast, removeToast } = useToast();
  const {
    exportComfyUIWorkflow,
    exportFreepikGraph,
    exportPrompts,
    exportRoundTripJSON,
  } = useExports();

  const [importOpen, setImportOpen] = useState(false);

  const handleNodeClick = useCallback(
    (_event: React.MouseEvent, node: { id: string }) => {
      setSelectedNodeId(node.id === selectedNodeId ? null : node.id);
    },
    [selectedNodeId, setSelectedNodeId]
  );

  const handleCopyPrompt = useCallback(
    (prompt: string) => {
      navigator.clipboard.writeText(prompt);
      addToast('success', 'Prompt copied to clipboard');
    },
    [addToast]
  );

  const handleExportComfyUI = useCallback(() => {
    if (!envelope) return;
    exportComfyUIWorkflow(envelope);
    addToast('success', 'ComfyUI workflow exported');
  }, [envelope, exportComfyUIWorkflow, addToast]);

  const handleExportFreepik = useCallback(() => {
    if (!envelope) return;
    exportFreepikGraph(envelope);
    addToast('success', 'Freepik graph exported');
  }, [envelope, exportFreepikGraph, addToast]);

  const handleExportPrompts = useCallback(() => {
    if (!envelope) return;
    exportPrompts(envelope);
    addToast('success', 'Prompt sheet exported');
  }, [envelope, exportPrompts, addToast]);

  const handleExportJSON = useCallback(() => {
    if (!envelope) return;
    exportRoundTripJSON(envelope, nodes);
    addToast('success', 'Phase 5 JSON exported');
  }, [envelope, nodes, exportRoundTripJSON, addToast]);

  const handleDragStart = useCallback((nodeType: string) => {
    // Store node type for drop handling
    window.__dragNodeType = nodeType;
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const nodeType = window.__dragNodeType;
      if (!nodeType) return;

      // Calculate position relative to canvas
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // TODO: In a full implementation, we'd add the node via usePhase6State
      // For now, just show a toast
      addToast('info', `Node type "${nodeType}" would be added at (${Math.round(x)}, ${Math.round(y)})`);
    },
    [addToast]
  );

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-[#0a0c10]">
      {/* Toast notifications */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      {/* Import Modal */}
      <ImportModal
        open={importOpen}
        onClose={() => setImportOpen(false)}
        onImport={(env) => {
          loadEnvelope(env);
          addToast('success', `Loaded: ${env.metadata.title} · ${env.documents.ai_node_graph.nodes.length} nodes`);
        }}
        addToast={addToast}
      />

      {/* Toolbar */}
      <Toolbar
        envelope={envelope}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onImport={() => setImportOpen(true)}
        onResetLayout={resetLayout}
        onUndo={undo}
        onRedo={redo}
        canUndo={canUndo}
        canRedo={canRedo}
        onExportComfyUI={handleExportComfyUI}
        onExportFreepik={handleExportFreepik}
        onExportPrompts={handleExportPrompts}
        onExportJSON={handleExportJSON}
      />

      {/* Main content area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left: Node Palette */}
        {viewMode === 'canvas' && <NodePalette onDragStart={handleDragStart} />}

        {/* Center: Canvas or Summary */}
        <div
          className="relative flex-1"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {viewMode === 'canvas' ? (
            <ReactFlowProvider>
              <FlowCanvas
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                onNodeClick={handleNodeClick}
                selectedNodeId={selectedNodeId}
              />
            </ReactFlowProvider>
          ) : envelope ? (
            <SummaryView envelope={envelope} />
          ) : (
            <div className="flex h-full items-center justify-center text-white/30">
              Import a Phase 5 envelope to see the summary.
            </div>
          )}
        </div>

        {/* Right: Inspector */}
        <Inspector
          node={selectedNode}
          envelope={envelope}
          onDelete={deleteNode}
          onCopyPrompt={handleCopyPrompt}
        />
      </div>
    </div>
  );
}

// Global type for drag node tracking
declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    __dragNodeType?: string;
  }
}
