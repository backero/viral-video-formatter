import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export interface NuggetOption {
  title: string;
  whyItWorks: string;
  point: string;
  whyTheyCare: string;
  proof: string;
}

export interface FormData {
  // Video Identity
  date: string;
  creator: string;
  actor: string;
  company: string;
  platform: string;
  estimatedLength: string;
  aspectRatio: string;
  actorCount: number;
  language: string;
  // Research
  research: string;
  // AI-extracted nuggets (real API response lives here)
  nuggetOptions: NuggetOption[] | null;
  selectedNuggetIndex: number | null;
  // Topic — Forced Format
  niche: string;
  subNiche: string;
  thePoint: string;
  whyTheyCare: string;
  theProof: string;
  // Value Delivery
  actionableTakeaway: string;
}

interface FormDataContextValue {
  data: FormData;
  updateData: (patch: Partial<FormData>) => void;
  resetData: () => void;
}

const STORAGE_KEY = 'viralform_data';

const defaultData: FormData = {
  date: '',
  creator: '',
  actor: '',
  company: '',
  platform: '',
  estimatedLength: '',
  aspectRatio: '9:16',
  actorCount: 1,
  language: 'EN',
  research: '',
  nuggetOptions: null,
  selectedNuggetIndex: null,
  niche: '',
  subNiche: '',
  thePoint: '',
  whyTheyCare: '',
  theProof: '',
  actionableTakeaway: '',
};

const FormDataContext = createContext<FormDataContextValue | undefined>(undefined);

export function FormDataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<FormData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? { ...defaultData, ...JSON.parse(saved) } : defaultData;
    } catch {
      return defaultData;
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const updateData = (patch: Partial<FormData>) => {
    setData((prev) => ({ ...prev, ...patch }));
  };

  const resetData = () => {
    setData(defaultData);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <FormDataContext.Provider value={{ data, updateData, resetData }}>
      {children}
    </FormDataContext.Provider>
  );
}

export function useFormData() {
  const ctx = useContext(FormDataContext);
  if (!ctx) throw new Error('useFormData must be used within FormDataProvider');
  return ctx;
}
