import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import Anthropic from '@anthropic-ai/sdk';

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const MODEL = 'claude-sonnet-4-5-20250929';

// Simple health check
app.get('/api/health', (req, res) => {
  res.json({ ok: true, hasKey: Boolean(process.env.ANTHROPIC_API_KEY) });
});

/**
 * POST /api/extract-nuggets
 * Body: { research: string, niche?: string }
 * Returns 3 "nugget" options extracted from the raw research dump,
 * in the exact shape the Phase1 UI expects.
 */
app.post('/api/extract-nuggets', async (req, res) => {
  try {
    const { research } = req.body;

    if (!research || research.length < 50) {
      return res.status(400).json({ error: 'research text is too short' });
    }

    const prompt = `You are helping a short-form video creator turn raw research notes into 3 distinct "single point" options for a viral video script.

RAW RESEARCH:
"""
${research}
"""

Return ONLY valid JSON (no markdown fences, no preamble) in this exact shape:

{
  "options": [
    {
      "title": "short label for this angle (max 8 words)",
      "whyItWorks": "one sentence on why this specific angle would stop a scroller (max 40 words)",
      "point": "the single point the video will make (max 20 words)",
      "whyTheyCare": "why the audience cares, ideally with a stat from the research (max 20 words)",
      "proof": "credibility/proof point pulled from the research (max 20 words)"
    }
  ]
}

Generate exactly 3 options, each a genuinely different angle on the same research. Use only facts present in the research above — do not invent statistics.`;

    const message = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    });

    const textBlock = message.content.find((block) => block.type === 'text');
    const raw = textBlock ? textBlock.text : '{}';
    const cleaned = raw.replace(/```json|```/g, '').trim();

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (e) {
      return res.status(502).json({ error: 'AI returned non-JSON output', raw: cleaned });
    }

    res.json(parsed);
  } catch (err) {
    console.error('extract-nuggets error:', err);
    res.status(500).json({ error: err.message || 'internal error' });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`ViralForm backend running on http://localhost:${PORT}`);
  console.log(`API key loaded: ${process.env.ANTHROPIC_API_KEY ? 'yes' : 'NO - set it in server/.env'}`);
});
